<?php
$_c['domain'] = 'your domain';
$_c['host'] = 'localhost';
$_c['user'] = 'db user';
$_c['pass'] = 'db pass';
$_c['db'] = 'db name';
$_c['path'] = $_SERVER['DOCUMENT_ROOT'];
$_c['app'] = 'demo';
$_c['app_path'] = $_c['path'].'/app/'.$_c['app'];
