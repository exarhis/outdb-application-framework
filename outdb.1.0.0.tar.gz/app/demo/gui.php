<?php
function categories($uri)
{
    global $_c;
   
    $sections = db("SELECT * FROM `registry` WHERE `uri` LIKE '".$uri."';");
    $count = count($sections);
    echo '<div>';
    for($i=0;$i<$count;$i++)
    {
        $all_count = db_rows_num("SELECT `id` FROM `registry` WHERE `status` IS NULL AND `service` LIKE 'topic' AND  `section` LIKE '".$sections[$i]['section']."' GROUP BY `url`");
        $sec = db("SELECT `value`,`uri` FROM `sections` WHERE `uri` LIKE '".$sections[$i]['section']."' LIMIT 1;");
        echo '<a href="'.$_c['domain'].'/'.$sec['uri'].'" class="badge badge-light"> '.$sec['value'].'<span class="badge badge-light">'.$all_count.'</span></a>';
    }
    echo '</div>';
}

function article_desc_html($uri)
{
    global $_c;
    $olat= db_rows_num("SELECT `id` FROM `registry` WHERE `status` IS NULL AND `service` LIKE 'opinion' AND  `topic` LIKE '".$uri."' GROUP BY `uri` ");
    $olao= db_rows_num("SELECT `id` FROM `registry` WHERE `status` IS NULL AND `service` LIKE 'comment' AND  `topic` LIKE '".$uri."' GROUP BY `uri`");
    $dir = registry($url);
    $time = db("SELECT `time` FROM `registry` WHERE `uri` LIKE '$uri' LIMIT 1;");
    $views = db("SELECT `views` FROM `registry` WHERE `uri` LIKE '".$dir['topics']['uri']."' LIMIT 1;");
   
echo '<h3>'.$dir['users']['name'].' : <a href="'.$dir['topics']['uri'].'"> '.$dir['topics']['description'].'</a></h3>

 '; echo 'Απαντήσεις : '.$olat.' ';
 echo 'Σχόλια :  '.$olao.' - ';
 echo date("d/n/Y H:i:s",$time);
 if(empty($views)) $views = 1;
 echo ' - Εμφανίσεις  : '.$views; 
echo '<div class="gap"></div>';
}

function article_html($uri)
{
    global $_c,$service;
    if($service!='topic') $li = '<i class="fas fa-link"></i>'; else $li = '';
    $registry = registry($uri);
    global $_c;
    $olat= db_rows_num("SELECT `id` FROM `registry` WHERE `status` IS NULL AND `service` LIKE 'opinion' AND  `topic` LIKE '".$uri."' GROUP BY `opinion`");
 
    $dir = registry($uri);
    
    echo article_desc_html($registry['topics']['uri']).'
    <div class="topic">'. nl2br($registry['topics']['text']).'</div>';
    
    if(!empty($registry['topics']['img'])){
        $images = explode(';',$registry['topics']['img']);
        foreach($images AS $image)
        {
        echo '<a href="'.$_c['domain'].'/'.$image,'" target="_blank" ><img src='.$_c['domain'].'/'.$image,' class="imgs"></a>';
        }
        }
        
}

function opinion_html($uri)
{    
    global $_c;
    $dir = registry($uri);
    $olao= db_rows_num("SELECT `id` FROM `registry` WHERE `status` IS NULL AND `service` LIKE 'comment' AND  `opinion` LIKE '".$dir['opinions']['uri']."' GROUP BY `url`");

    echo '<div class="gap"></div><a href="'.$_c['domain'].'/'.$uri.'"><i class="fas fa-link"></i> Σχόλια : '.$olao.'</a><div class="opinion">'.$dir['users']['name'].' :   '.$dir['opinions']['opinion'].'</div>
    <a href="'.$_c['domain'].'/'.$dir['opinions']['uri'].'"></a>
    <div class="gap"></div>
    <hr>';

   

}

function comment_html($uri)
{
    $dir = registry($uri);
    echo '<div class="gap"></div><div class="comment">'.$dir['users']['name'].' : '.$dir['comments']['comment'].'</div><a href="'.$dir['comments']['uri'].'"></a>';

}